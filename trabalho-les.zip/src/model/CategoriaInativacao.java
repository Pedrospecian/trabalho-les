package model;

import java.util.Date;

public class CategoriaInativacao extends Catbase {
	public CategoriaInativacao(long id, Date dataCadastro, String nome) {
		super(id, dataCadastro, nome);
	}

}
