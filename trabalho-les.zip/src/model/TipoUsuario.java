package model;

import java.util.Date;

public class TipoUsuario extends Tipo {
	public TipoUsuario(long id, Date dataCadastro, String nome, String descricao) {
		super(id, dataCadastro, nome, descricao);
	}

}
