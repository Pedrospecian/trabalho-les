package model;

import java.util.Date;

public class TipoLogradouro extends Tipo {
	public TipoLogradouro(long id, Date dataCadastro, String nome, String descricao) {
		super(id, dataCadastro, nome, descricao);
	}

}
