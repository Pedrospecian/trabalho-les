package model;

import java.util.Date;

public class Categoria extends Catbase {
	public Categoria(long id, Date dataCadastro, String nome) {
		super(id, dataCadastro, nome);
	}

}
