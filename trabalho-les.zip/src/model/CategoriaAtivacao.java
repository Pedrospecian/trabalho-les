package model;

import java.util.Date;

public class CategoriaAtivacao extends Catbase {
	public CategoriaAtivacao(long id, Date dataCadastro, String nome) {
		super(id, dataCadastro, nome);
	}

}
