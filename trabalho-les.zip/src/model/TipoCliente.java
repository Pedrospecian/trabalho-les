package model;

import java.util.Date;

public class TipoCliente extends Tipo {
	public TipoCliente(long id, Date dataCadastro, String nome, String descricao) {
		super(id, dataCadastro, nome, descricao);
	}

}
