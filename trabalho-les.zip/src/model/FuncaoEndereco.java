package model;

import java.util.Date;

public class FuncaoEndereco extends Tipo {	
	public FuncaoEndereco(long id, Date dataCadastro, String nome, String descricao) {
		super(id, dataCadastro, nome, descricao);
	}
}
