package model;

import java.util.Date;

public class Bandeira extends Catbase {
	public Bandeira(long id, Date dataCadastro, String nome) {
		super(id, dataCadastro, nome);
	}

}
