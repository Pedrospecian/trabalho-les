package model;

import java.util.Date;

public class TipoEndereco extends Tipo {
	public TipoEndereco(long id, Date dataCadastro, String nome, String descricao) {
		super(id, dataCadastro, nome, descricao);
	}

}
