package model;

import java.util.Date;

public class Genero extends Catbase {
	public Genero(long id, Date dataCadastro, String nome) {
		super(id, dataCadastro, nome);
	}

}
