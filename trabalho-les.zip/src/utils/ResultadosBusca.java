package utils;

import java.util.ArrayList;

public class ResultadosBusca {
	private ArrayList resultados;

	public ArrayList getResultados() {
		return this.resultados;
	}

	public void setResultados(ArrayList resultados) {
		this.resultados = resultados;
	}

	public ResultadosBusca(ArrayList resultados) {
		this.resultados = resultados;
	}
}
